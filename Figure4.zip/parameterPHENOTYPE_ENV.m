function [theta] = parameterPHENOTYPE_ENV(AILE, FOR, g, SST) 
% PARAMETERPHENOTYPE_ENV calculates the demographic parameter matrix used
% to parameterize the eco-evolutionary matrix population model.
%
% The function calculates survival, recruitment, breeding probability, and
% breeding-success parameters as functions of sea-surface temperature,
% wing length, and foraging and phenological traits.
%
% This function uses the same demographic relationships as the historical
% parameterization. Environmental variation among years or climate
% scenarios is introduced through the SST input supplied for each annual
% projection.
%
% DESCRIPTION OF INPUTS
%
% AILE = Wing-length values for the phenotype classes.
%        AILE is a vector of dimension g containing one wing-length value
%        for each phenotype class. Wing length is measured at fledging.
%
% FOR  = Foraging and phenological trait values for the phenotype classes.
%        FOR is a g-by-3 matrix, with one row for each phenotype class:
%           Column 1: FOR, number of transitions between activity and rest
%                     on the water
%           Column 2: ACT, proportion of time spent on the water
%           Column 3: Return date to the breeding colony
%
% g    = Number of phenotype classes and number of columns in theta.
%
% SST  = Sea-surface-temperature covariates for the current projection year.
%        The environmental covariates are used as follows:
%           SST(1,1): SST affecting first-year survival
%           SST(1,2): SST affecting pre-breeder breeding success and adult
%                     breeding probabilities
%           SST(1,3): Additional SST covariate affecting pre-breeder
%                     breeding success and adult breeding probabilities
%
% DESCRIPTION OF OUTPUT
%
% theta = 14-by-g matrix of demographic parameters.
%         Each column corresponds to one phenotype class. The rows retain
%         the following fixed order:
%            Row 1:      First-year survival
%            Row 2:      Pre-breeder survival
%            Row 3:      Survival of successful breeders
%            Row 4:      Survival of failed breeders and non-breeders
%            Row 5:      Recruitment probability at age 4
%            Row 6:      Recruitment probability at age 5
%            Row 7:      Recruitment probability at age 6
%            Row 8:      Recruitment probability at age 7
%            Row 9:      Recruitment probability at age 8 and older
%            Row 10:     Pre-breeder breeding success
%            Row 11:     Breeding probability of successful breeders
%            Row 12:     Breeding probability of failed breeders
%            Row 13:     Breeding probability of non-breeders
%            Row 14:     Adult breeding success
%
% REFERENCE
%
% Jenouvrier, S., Aubry, L. M., Barbraud, C., Weimerskirch, H., &
% Caswell, H. (2018). Interacting effects of unobserved heterogeneity and
% individual stochasticity in the life history of the Southern Fulmar.
% Journal of Animal Ecology, 87, 212-222.
% https://doi.org/10.1111/1365-2656.12752

%% INITIALIZE theta matrix
theta = zeros(14, g); % There are 14  parameters. Because environmental conditions change at each year, parameters in theta need to be re-estimated each year

% First year survival Function of SST and wing length
%baseline
theta(1, :) = invlogit(-0.23 - 0.24.*SST(1, 1) - 0.32.*SST(1, 1).^2 + 0.368056458*AILE); % Effect of SST in juvenile sector + effect of wing length
% adult survival 
theta(2, :) = ones(1, g).*0.93;% Survival Pre-breeders
theta(3, :) = ones(1, g).*0.94;% Survival Successful
theta(4, :) = ones(1, g).*0.92;% Survival Failed=Non-breeders
% recruitment probabilities: Function of age (different intercepts for each age) and wing length (same slope accross age classes)
theta(5, :) = invlogit(-4.891594061 + 0.385926122.*AILE); % age 4;  
theta(6, :) = invlogit(-3.556583792 + 0.385926122.*AILE); % age 5;  
theta(7, :) = invlogit(-2.247152916 + 0.385926122.*AILE); % age 6;  
theta(8, :) = invlogit(-1.511223273 + 0.385926122.*AILE); % age 7;  
theta(9, :) = invlogit(-0.8954 + 0.385926122.*AILE); % age 8+;  
% breeding success PB Function of SST 
theta(10,:)=ones(1, g).*invlogit(-0.300619322 - 0.154409282.*SST(1, 2) - 0.049391794.*SST(1, 2).^2 + 0.135000818.*SST(1, 3) + 0.135000818.*SST(1, 3).^2);
% Breeding probabilities of Adult
%Successful
theta(11,:) = exp(1.2843 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) ./ ...
               (1 + exp(1.2843 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) + ...
                    exp(0.6537 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2)) ...
             + exp(0.6537 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) ./ ...
               (1 + exp(0.6537 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) + ...
                    exp(1.2843 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2));

%Failed
theta(12,:) = exp(0.8144 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) ./ ...
               (1 + exp(0.8144 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) + ...
                    exp(0.3905 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2)) ...
             + exp(0.3905 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) ./ ...
               (1 + exp(0.3905 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) + ...
                    exp(0.8144 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2));

% Non-breeders
theta(13,:)=exp(0.0130 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) ./ ...
(1 + exp(0.0130 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) + ...
     exp(-0.2112 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2)) ...
+ exp(-0.2112 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) ./ ...
(1 + exp(-0.2112 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) + ...
     exp(0.0130 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2));
% breeding success adult (no differences among breeding stages): Function
% of forgaing behaviors
theta(14,:)=invlogit(0.9785 + 0.4366.*FOR(:, 3) + 1.3643.*FOR(:, 1) - 0.4593.*FOR(:, 2));

return
