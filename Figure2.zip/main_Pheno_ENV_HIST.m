% %Required inputs ###########################################
%      - PHENOTYPE (integer): selects which trait is modeled.
% 1 = number of landings / take-offs
% 2 = time resting on the water
% 3 = return date
% 4 = wing length
% 
%     - h2 (scalar in [0,1]): narrow-sense heritability used to partition phenotypic variance into additive genetic and environmental components (Va = Vp*h2, Ve = Vp - Va).
%     - nit (integer): number of time steps for the main projection (here 115, corresponding to 1986–2100 ).
%     - nind (integer): initial total population size used to scale the post burn-in distribution (here 2815).
% 
%     - Dimensions
% w (integer): number of age classes within each breeding state  
% g (integer): number of bins for phenotype value categories  
% b (integer): number of bins for breeding values.
% 
%     - Trait and covariate data (empirical inputs)
% Wing (vector): wing length data (used when PHENOTYPE = 4).
% FOR (matrix): foraging data where columns are used as:
%                        FOR(:,2) = landings / take-offs (PHENOTYPE 1)
%                        FOR(:,3) = time on water / resting (PHENOTYPE 2)
%                         FOR(:,4) = return date (PHENOTYPE 3)
% FOR_mean (vector or scalar): mean foraging covariates 
% SST (vector time series or scalar): sea surface temperature covariate 

% % OUTputs ###########################################
% 
% - Time and grid outputs
% 
% nit (scalar): number of time steps in main projection.
% midpoint_e (1xg): phenotype bin midpoints.
% midpoint_a (1xb): breeding value bin midpoints.
% xp (scalar): range used to define midpoint.
% 
% - Population and distribution outputs
% 
% NN (w × b × g × nit): full population distribution through time, structured as
% age ×  breeding value bin × phenotype x time
% NN_tot (nit×1): total population size through time, obtained by integrating NN over structured dimensions (with binwidth scaling).
% 
% - Breeding value outputs
% 
% m_ebvs (1×nit): mean breeding value through time (population-weighted average of midpoint_a).
% m_ebvs2 (b×nit): normalized breeding value distribution through time (each time step sums to 1 after binwidth scaling).
% Va_hat (1×nit): estimated additive genetic variance of breeding values through time, computed from ebvs and m_ebvs.
% 
% - Phenotype outputs
% 
% Pheno (g×nit): phenotype distribution of the total population through time (integrated over age and breeding values).
% mz (1×nit): mean phenotype of the total population through time.
% Mz (wxnit)
% Vp_hat (1×nit): estimated phenotypic variance through time
% 
% Vital-rate summaries (phenotype-weighted means)
% These are phenotype-weighted mean rates through time, computed from Thetatime and Pheno:
% 
% - S1z (1×nit): mean of juvenile survival through time.
% - R4z, R5z, R6z, R7z, R8z, R9z (1×nit): mean recruitment probabilities  (parameters 5–9 as indexed for age) through time.
% - BSz (1×nit): mean breeding success through time.

% time vector 
nit=115; %1986-2100
%***********************************************************************
% number of individuals to simulate
nind = 2815; % Fra estination 1986


min_pheno    = -6;
max_pheno    = 6;
edges_e    = linspace(min_pheno, max_pheno, g+1);  % Define the bin edges
midpoint_e = (edges_e(1:end-1)+edges_e(2:end))/2;
binwidth_e = edges_e(2) - edges_e(1); % Bin width

THETAtime = zeros(nit,14,g);

switch PHENOTYPE
    case 4 %---------------------------------------------------------------
        % calculate the vector of parameter where PHENOTYPE is WING LENGTH
        Data = Wing;
        [theta] = parameterPHENOTYPE_HIST(midpoint_e', FOR_mean, g, SST) ;

    case 3 %---------------------------------------------------------------
        % where PHENOTYPE is return date
        Data = FOR(:,4);
        Foraging = [repmat(mean(FOR(:,2)), g, 1), ...
            repmat(mean(FOR(:,3)), g, 1), ...
            midpoint_e'];
        [theta] = parameterPHENOTYPE_HIST(mean(Wing), Foraging, g,SST);

    case 2 %---------------------------------------------------------------
        % where PHENOTYPE is 'Time resting on the water'
        Data = FOR(:,3);
        Foraging = [repmat(mean(FOR(:,2)), g, 1),...
            midpoint_e',...
            repmat(mean(FOR(:,4)), g, 1)];
        [theta] = parameterPHENOTYPE_HIST(mean(Wing), Foraging, g,SST);
    case 1 %---------------------------------------------------------------
        % where PHENOTYPE is Number of landings / take-offs
        Data = FOR(:,2);
        Foraging = [midpoint_e', ...
            repmat(mean(FOR(:,3)), g, 1), ...
            repmat(mean(FOR(:,4)), g, 1)];
        [theta] = parameterPHENOTYPE_HIST(mean(Wing), Foraging, g,SST);
end
Vp    = var(Data);
Meanp = mean(Data);
THETAtime(1,:,:) = theta;

% distribution initiale
nphen = exp(-(midpoint_e-Meanp).^2/(2*Vp));
Nphen = nphen./(sum(nphen).*binwidth_e);

%% ***********************************************************************
% quantitative genetic
% heritability / Va males
% Vp is the variance of teh phenotypic distribution
Va = Vp*h2;
Ve = Vp - Va; % Get the environmental variance (Vp = Va + Ve)
%***********************************************************************
% Breeding value
% min and max breeding values
xp = 6;
% Imagine a BV ranging between -xp and xp
min_breeding = -xp;
max_breeding = xp;

% Get the categories of breeding values
edges_a    = linspace(min_breeding,max_breeding,g+1);
midpoint_a = (edges_a(1:end-1)+edges_a(2:end))/2;
binwidth_a = edges_a(2) - edges_a(1); % Bin width
midpoint2_a = 2*midpoint_a(1):binwidth_a:2*midpoint_a(end);

%% ***********************************************************************
% Function that Initiate pheno distrib Gaussian centré en mean_pheno
%The function f_ea takes a breeding value x and maps it to a phenotypic value. It does this by scaling the breeding value using the relationship between the phenotypic range and breeding value range, and then adjusting it by the mean phenotypic value mu_e.
mu_e = (midpoint_e(end)+midpoint_e(1))/2;
nbv = exp(-(midpoint_a-Meanp).^2/(2*Va));
Nbv = nbv./(sum(nbv).*binwidth_a);
% ***********************************************************************
%% *************************Initiate Identity matrices ********************
% Initiate B matrix:  breeding value within stage within the phenotype
B = speye(b*w*g,b*w*g);
% Initiate P matrix: phenotype within the stage within the breeding value
P = speye(b*w*g,b*w*g);
%***********************************************************************
%% ***********************************************************************
%% ***********************************************************************
% Function that Initiate pheno distrib Gaussian centré en mean_pheno
%The function f_ea takes a breeding value x and maps it to a phenotypic value. It does this by scaling the breeding value using the relationship between the phenotypic range and breeding value range, and then adjusting it by the mean phenotypic value mu_e.
f_ea = @(x) (midpoint_e(end)-midpoint_e(1))/(2*midpoint_a(end))*x+mu_e;
%**************************************
% For each breeding value, what is the potential distribution of offspring phenotype? - Here we add noise (Ve) to the breeding value to obtain offspring phenotype
emat = exp(-(midpoint_e'-f_ea(midpoint_a)).^2./(2*Ve)).*binwidth_a./sum(exp(-(midpoint_e'-f_ea(midpoint_a)).^2./(2*Ve)).*binwidth_e,1);

% Ftilde/ H matrix breeding value within stage within the phenotype
% To construct the H matrix, we need the Ga matrix and the function GVLE
Vle = Va;
GVLE = @(zz) exp(-zz.^2/Va)/sqrt(pi*Va); % Define a new function that gets probabilities from the normal distribution
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%  Compute N(t)
%% Initialization 

%% Get the matrices U, B, P for Utilde and R, H, M for Ftilde
[~,Ptype] = ind2sub([b,g],1);
Ui = sparse(Umat2(theta(:, Ptype)));
[idr,~] = find(Ui);
nId = length(idr);
Idr = zeros(nId*b*g,1); Idc = zeros(nId*b*g,1);
Uu   = zeros(nId*b*g,1);
for iu = 1:b*g
    Ik = ((iu-1)*nId+1):iu*nId;
    [~,Ptype] = ind2sub([b,g],iu);
    Ui = sparse(Umat2(theta(:, Ptype)));
    [idr,idc] = find(Ui);
    Idr(Ik) = idr+(iu-1)*w;Idc(Ik) = idc+(iu-1)*w;
    Uu(Ik) = nonzeros(Ui);
end
U = sparse(Idr,Idc,Uu,b*w*g,b*w*g);
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
% The matrix M, which is the transmission of maternal phenotype to offspring phenotype goes through the breeding values only
nId = g*g;
Idr = zeros(nId*b,1); Idc = zeros(nId*b,1);
Mm  = zeros(nId*b,1);
inew = 0;
for i = 1:b
    iold = inew;
    [idr,~,Mi_n] = find(emat(:,i));
    inew =  length(idr);
    idc = reshape(repmat(1:g,inew,1),g*inew,1);
    idr = reshape(repmat(idr,g,1),g*inew,1); 
    Ik = ((i-1)*nId+1):(((i-1)*nId+1)+inew*g-1);
    Idr(Ik) = idr+((i-1)*w*g); Idc(Ik) = idc+((i-1)*w*g);
    Mm(Ik) = reshape(repmat(Mi_n,g,1),g*inew,1);
end
Idr = nonzeros(Idr);
Idc = nonzeros(Idc);
Mm = nonzeros(Mm);
M = sparse(Idr,Idc,Mm,b*w*g,b*w*g);
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%% Ftilde/ R matrix  stage within the breeding value within phenotype
[~,Ptype] = ind2sub([b,g],1);
Ri = sparse(Fmat2(theta(:, Ptype)));
[idr,~] = find(Ri);
nId = length(idr);
Idr = zeros(nId*b*g,1); Idc = zeros(nId*b*g,1);
Rr   = zeros(nId*b*g,1);
for ir = 1:b*g
    Ik = ((ir-1)*nId+1):ir*nId;
    [~,Ptype] = ind2sub([b,g],ir);
    Ri = sparse(Fmat2(theta(:, Ptype)));
    [idr,idc] = find(Ri);
    Idr(Ik) = idr+(ir-1)*w;Idc(Ik) = idc+(ir-1)*w;
    Rr(Ik) = nonzeros(Ri);
end
R = sparse(Idr,Idc,Rr,b*w*g,b*w*g);
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

%% Initial vector of population size at t
NNinit   = Nbv'*Nphen;
nninit = reshape(NNinit,[1,b,g]);
SAD = [
    0.13;
    0.06;
    0.05;
    0.05;
    0.05;
    0.04;
    0.04;
    0.03;
    0.03;
    0.05;
    0.26;
    0.11;
    0.10
    ];


%% projections 
%_______________________________________________________________________
Ninit = nind*repmat(SAD,1,b).*nninit;
nit_0 = 50;
N      = zeros(w*b*g, nit_0);
N(:,1) = Ninit(:);
% first for burning / initialisation
for it = 2:nit_0  
    % define vector of parmeter , U and R based on SST at time i SST
    % Live individual transitions ----------------------------------------------------
    % Process #1.1 = Transition of live individuals between states
    NU = U*N(:,it-1);

    % Rearrange for process #1.2
    nu   = reshape(NU,[w,b,g]);
    nu_r = permute(nu(:,:,:),[2,1,3]); % bwg
    nu_r = nu_r(:);

    % Process #1.2 = Transition of live individuals between breeding value categories (assumed fixed)
    NB = B*nu_r;

    % Rearrange for process #1.3
    nb   = reshape(NB, [b,w,g]);
    nb_r = permute(nb, [3,1,2]);
    nb_r = nb_r(:);

    % Process #1.3 = Transition of live individuals between phenotypic categories (assumed fixed)
    NP = P*nb_r;

    % Rearrange back to initial configuration (stage within breeding value within phenotype)
    np   = reshape(NP, [g,b,w]);
    np_r = permute(np, [3,2,1]);
    np_r = np_r(:);
    NU_final = np_r; 

    % Reproduction ----------------------------------------------------
    % Process #2.1 = Offspring production
    NF = R*N(:,it-1);

    % Rearrange for process #2.2
    nf = reshape(NF,[w,b,g]);
    n  = permute(nf(1,:,:),[3,2,1]); % g,b,1  This is a matrix of offspring produced from maternal phenotypes (rows) and breeding values (columns)
    nn = sum(n,1)./sum(n*binwidth_a,'all');

    % Process #2.2 = Transmission of breeding  value
    Gle = GVLE(0.5*(midpoint2_a));
    H1  = conv2(nn,Gle*binwidth_a);
    H2  = conv2(H1*binwidth_a,n);
    bb2 = (2*midpoint_a(1):(binwidth_a/2):2*midpoint_a(end));
    H3  = (interp1(bb2,H2',midpoint_a));
    nf(1,:,:) = H3;

    % Rearrange for process #2.3
    NH = reshape(permute(nf,[3,1,2]),w*g*b,1);

    % Process # 2.3 = Attribution of offspring phenotype
    NM = M*NH;

    % Rearrange back to initial configuration (state within breeding value within phenotype)
    nm = permute(reshape(NM,[g,w,b]),[2,3,1]);
    nm_r = reshape(nm,w*b*g,1);
    NF_final = nm_r;

    % Add all processes to get total population size
    N(:,it) = NF_final+NU_final;
end
%_______________________________________________________________________

%Ninit = N(:,end);
Ninit = nind .* (N(:,end) ./ sum(N(:,end)*binwidth_a*binwidth_e));
%Ninit=N(:,end);
N      = zeros(w*b*g, nit);
N(:,1) = Ninit(:);

%% projections
for it = 2:nit 
    THETAtime(it,:,:) = theta;
    % define vector of parmeter , U and R based on SST at time i SST
    % Live individual transitions ----------------------------------------------------
    % Process #1.1 = Transition of live individuals between states
    NU = U*N(:,it-1);

    % Rearrange for process #1.2
    nu   = reshape(NU,[w,b,g]);
    nu_r = permute(nu(:,:,:),[2,1,3]); % bwg
    nu_r = nu_r(:);

    % Process #1.2 = Transition of live individuals between breeding value categories (assumed fixed)
    NB = B*nu_r;

    % Rearrange for process #1.3
    nb   = reshape(NB, [b,w,g]);
    nb_r = permute(nb, [3,1,2]);
    nb_r = nb_r(:);

    % Process #1.3 = Transition of live individuals between phenotypic categories (assumed fixed)
    NP = P*nb_r;

    % Rearrange back to initial configuration (stage within breeding value within phenotype)
    np   = reshape(NP, [g,b,w]);
    np_r = permute(np, [3,2,1]);
    np_r = np_r(:);
    NU_final = np_r; 

    % Reproduction ----------------------------------------------------
    % Process #2.1 = Offspring production
    NF = R*N(:,it-1);

    % Rearrange for process #2.2
    nf = reshape(NF,[w,b,g]);
    n  = permute(nf(1,:,:),[3,2,1]); % g,b,1  This is a matrix of offspring produced from maternal phenotypes (rows) and breeding values (columns)
    nn = sum(n,1)./sum(n*binwidth_a,'all');

    % Process #2.2 = Transmission of breeding  value
    Gle = GVLE(0.5*(midpoint2_a));
    H1  = conv2(nn,Gle*binwidth_a);
    H2  = conv2(H1*binwidth_a,n);
    bb2 = (2*midpoint_a(1):(binwidth_a/2):2*midpoint_a(end));
    H3  = (interp1(bb2,H2',midpoint_a));
    nf(1,:,:) = H3;

    % Rearrange for process #2.3
    NH = reshape(permute(nf,[3,1,2]),w*g*b,1);

    % Process # 2.3 = Attribution of offspring phenotype
    NM = M*NH;

    % Rearrange back to initial configuration (state within breeding value within phenotype)
    nm = permute(reshape(NM,[g,w,b]),[2,3,1]);
    nm_r = reshape(nm,w*b*g,1);
    NF_final = nm_r;

    % Add all processes to get total population size
    N(:,it) = NF_final+NU_final;
end

NN     = reshape(N,[w,b,g,nit]); %pop strutured by stage * breeding values; phenotype, time
NN_tot = permute(sum(NN*binwidth_a*binwidth_e,[1,2,3]),[4,1,2,3]);

% breeding value moyenne all
ebvs   = permute(sum(NN*binwidth_e,[1,3]),[2,4,1,3]);
m_ebvs = sum(ebvs.*midpoint_a',1)./sum(ebvs,1); % breeding value moyenne
m_ebvs2 = ebvs./sum(ebvs.*binwidth_a,1); % distribution breeding value

pheno = permute(sum(NN*binwidth_a,[1,2]),[3,4,1,2]); % Phenotype distribution of total population
Pheno = permute(sum(NN*binwidth_a,2),[1,3,4,2]);     % Phenotype distribution per stage

mz    = sum(pheno.*midpoint_e',1)./sum(pheno,1); % mean phenotype of total pop 
Mz    = squeeze(sum(Pheno.*midpoint_e,2)./sum(Pheno,2)); % mean phenotype per stage 

Va_hat = sum(ebvs.*(midpoint_a'-m_ebvs).^2,1)./sum(ebvs,1); % estimated BV variance
Vp_hat = sum(pheno.*(midpoint_e'-mz).^2,1)./sum(pheno,1);   % estimated Pheno variance

V(1,1) = mean(m_ebvs(2:nit)-m_ebvs(1:nit-1)) ;% adaptation rate over time

Npc=100*(NN_tot(nit)-NN_tot(1))./NN_tot(1);
%% mean vital rates
Thetatime = permute(THETAtime,[2,3,1]);
S1z = permute(sum(Thetatime(1,:,:).*Pheno(1,:,:),2)./sum(Pheno(1,:,:),2),[2,3,1]);
R4z = permute(sum(Thetatime(5,:,:).*Pheno(5,:,:),2)./sum(Pheno(5,:,:),2),[2,3,1]);
R5z = permute(sum(Thetatime(6,:,:).*Pheno(6,:,:),2)./sum(Pheno(6,:,:),2),[2,3,1]);
R6z = permute(sum(Thetatime(7,:,:).*Pheno(7,:,:),2)./sum(Pheno(7,:,:),2),[2,3,1]);
R7z = permute(sum(Thetatime(8,:,:).*Pheno(8,:,:),2)./sum(Pheno(8,:,:),2),[2,3,1]);
R8z = permute(sum(Thetatime(9,:,:).*Pheno(9,:,:),2)./sum(Pheno(9,:,:),2),[2,3,1]);
R9z = permute(sum(Thetatime(9,:,:).*Pheno(10,:,:),2)./sum(Pheno(10,:,:),2),[2,3,1]);
BSz = permute(sum(Thetatime(14,:,:).*Pheno(11:13,:,:),[1,2])./sum(Pheno(11:13,:,:),[1,2]),[2,3,1]);

