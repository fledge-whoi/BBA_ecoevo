% Fig. 2 Adaptive dynamics of black-browed albatross under constant climate conditions.
% (A) Projected percent change in total population size of black-browed albatrosses at the Kerguelen
% Islands by 2100, relative to initial abundance in 1986, across four phenotypes. Bars represent
% outcomes from eco-evolutionary simulations under a constant historical climate (average sea surface
% temperatures from 1986–2022). Each bar corresponds to a different heritability value (ranging from
% 0.1 to 0.9), with a gradient from blue to yellow indicating increasing heritability. (B) Adaptation
% rates (rate of change in mean breeding value per year) predicted for each trait under constant historical
% sea surface temperatures, shown as a function of heritability. Colored lines correspond to the
% four traits.

% For historical Sea Surface Temperature (SST):
%This MATLAB workflow runs an eco-evolutionary, stage-structured projection for one focal phenotype (chosen by PHENOTYPE) over nit annual time steps.
% Individuals are structured by:
%age/stage (w age classes within each breeding state),
% breeding state (b states),
%breeding value category (g bins),
% phenotype category (g bins).


%% Initiate
clear; close all; clc; 
addpath(pwd)
% ******************** PHENOTYPE **************************************
phenotypeNames = {
    'Activity', ...     % 1 Number of landings / take-offs
    'Time water', ...   % 2 Time resting on the water
    'Return date', ...  % 3
    'Wing length'       % 4
    };
% Phenotype Observed ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
load ('FOR.mat') % FORAGING: 1: year; 2: Number of landings / take-offs; 3. 'Time resting on the water'; 4: return date for all year
load wing_corrected.mat % wing length
FOR_mean = mean(FOR(:,2:end)); % Mean foraging phenotype

% ******************** DIMENSIONS **************************************
% Three dimensions (m) of stages:
% 1) Age
% 2) Breeding value
% 3) Phenotype
m = 3;
%---------------------------------

%---------------------------------
% Set dimensions for stages
w = 13; % age (or stage)
% Set dimensions for phenotypes
g = 100; % # phenotype classes
% Set dimensions for breeding value
b = 100; % # breeding value classes
%***********************************************************************



%% RUN The model for historical Sea Surface Temperature (SST):
% Builds phenotype–environment–vital rate parameters (theta) for the chosen phenotype,  as a function of SST.
% Initializes a Gaussian distribution of phenotypes and breeding values with variance components set by heritability h2.
% Constructs sparse block matrices for survival/transition (U), reproduction (R), breeding-value inheritance (H), and phenotype assignment (M).
% Runs a burn-in (nit_0) to reach a stable joint distribution, rescales to nind, then runs the main projection (nit).
% Aggregates outputs: population size through time, distributions of breeding values and phenotypes, means/variances breeding values and phenotypes, adaptation rate, and mean vital rates weighted by phenotype distributions.

% % OUTputs ###########################################
% 
% - Time and grid outputs
% 
% nit (scalar): number of time steps in main projection.
% midpoint_e (1xg): phenotype bin midpoints.
% midpoint_a (1xb): breeding value bin midpoints.
% xp (scalar): range used to define midpoint.
% 
% - Population and distribution outputs
% 
% NN (w × b × g × nit): full population distribution through time, structured as
% age ×  breeding value bin × phenotype x time
% NN_tot (nit×1): total population size through time, obtained by integrating NN over structured dimensions (with binwidth scaling).
% 
% - Breeding value outputs
% 
% m_ebvs (1×nit): mean breeding value through time (population-weighted average of midpoint_a).
% m_ebvs2 (b×nit): normalized breeding value distribution through time (each time step sums to 1 after binwidth scaling).
% Va_hat (1×nit): estimated additive genetic variance of breeding values through time, computed from ebvs and m_ebvs.
% 
% - Phenotype outputs
% 
% Pheno (g×nit): phenotype distribution of the total population through time (integrated over age and breeding values).
% mz (1×nit): mean phenotype of the total population through time.
% Mz (wxnit)
% Vp_hat (1×nit): estimated phenotypic variance through time
% 
% Vital-rate summaries (phenotype-weighted means)
% These are phenotype-weighted mean rates through time, computed from Thetatime and Pheno:
% 
% - S1z (1×nit): mean of juvenile survival through time.
% - R4z, R5z, R6z, R7z, R8z, R9z (1×nit): mean recruitment probabilities  (parameters 5–9 as indexed for age) through time.
% - BSz (1×nit): mean breeding success through time.

% ^^^^^^^^^^^^^^^^^^^Sea Surface Temperature ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
SST=[  -0.7563   -0.3128   -0.8093]; % 1986:2022
for PHENOTYPE=1:4
    for h2=0.1:0.1:0.9

        run('main_Pheno_ENV_HIST.m')

        save(['ecoEvoResults_cst_h2_',num2str(h2, '%.1f'), '_PHENOTYPE_', num2str(PHENOTYPE),'.mat'], ...
            'nit', 'm_ebvs', 'Va_hat', 'm_ebvs2', ...
            'mz','Mz', 'Vp_hat', 'pheno', 'midpoint_e', ...
            'S1z', 'R4z', 'R5z', 'R6z', 'R7z', 'R8z', 'R9z','BSz', ...
            'NN', 'NN_tot','midpoint_a', 'xp');
    end
end

%% CALCULATE 
% Projected percent change in total population size^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
% Adaptation rates (rate of change in mean breeding value per year)
heritabilities=0.1:0.1:0.9;
nPhen = numel(phenotypeNames);
nH2 = numel(heritabilities);
baselineN = nind;

years = 1986:2100;
load Nobs_FRA.mat

for p = 1:nPhen
    for h = 1:nH2
        h2 = heritabilities(h);
        PHENOTYPE = p;

        fileName = sprintf('ecoEvoResults_cst_h2_%.1f_PHENOTYPE_%d.mat', ...
            h2, PHENOTYPE);
        if exist(fileName, 'file') % /Users/sjenouvrier/Library/CloudStorage/Dropbox/BBAwing2025/AnalysisMay_2025/MATresults/
            load(fileName, 'm_ebvs', 'NN_tot');
            adaptationRates(p,h) = abs(mean(diff(m_ebvs)));
            NN_tot_store{p,h} = NN_tot;
            %percent_change(p,h) = 100 * (NN_tot(end,1) - baselineN) / baselineN;
            percent_change(p,h) = 100 * (NN_tot(end,1) - NN_tot(1,1)) / NN_tot(1,1);
        else
            warning('%s not found', fileName);
            adaptationRates(p,h) = NaN;
            NN_tot_store{p,h} = nan(length(years),1);
            percent_change(p,h) = 100 * (NN_tot(end,1) - baselineN) / baselineN;
            percent_change(p,h) = 100 * (NN_tot(end,1) - NN_tot(1,1)) / NN_tot(1,1);

        end
    end
end

%% PLOT RESULTS
figure('Position', [100, 100, 1200, 500]);

% === Panel A: Percent Change in Population Size ===
subplot(1,2,1)
cmap = parula(nH2); % color-blind friendly colormap
barWidth = 0.8 / nH2;
hold on;

for h = 1:nH2
    x = (1:nPhen) - 0.4 + (h-1)*barWidth;
    bar(x, percent_change(:,h), barWidth, 'FaceColor', cmap(h,:), 'EdgeColor', 'none');
end

set(gca, 'XTick', 1:nPhen, 'XTickLabel', phenotypeNames, 'FontSize', 24);
ylabel('% Change in Population Size (2100 vs. 1986)', 'FontSize', 24);
yline(0, 'k--');
legend(arrayfun(@(h2) sprintf('h^2 = %.1f', h2), heritabilities, 'UniformOutput', false), ...
    'Location', 'northeast', 'FontSize', 14);
grid on;
box on;

% Add panel label A
text(0.02, 0.95, 'A', 'Units', 'normalized', ...
    'FontWeight', 'bold', 'FontSize', 28);

% === Panel B: Adaptation Rate vs. Heritability ===
subplot(1,2,2); hold on;

colors = lines(numel(phenotypeNames));
for pIdx = 1:numel(phenotypeNames)
    plot(heritabilities, adaptationRates(pIdx, :), '-o', ...
        'LineWidth', 3, 'Color', colors(pIdx,:), ...
        'DisplayName', phenotypeNames{pIdx});
end

xlabel('Heritability (h^2)', 'FontSize', 24);
ylabel('Adaptation rate (Δ breeding value / year)', 'FontSize', 24);
legend('Location', 'best', 'FontSize', 16);
set(gca, 'FontSize', 24);
grid on;
axis tight;

% Add panel label B
text(0.02, 0.95, 'B', 'Units', 'normalized', ...
    'FontWeight', 'bold', 'FontSize', 28);
set(gcf,'Renderer','painters')   % ensure vector rendering
exportgraphics(gcf,'figure2.pdf','ContentType','vector');
