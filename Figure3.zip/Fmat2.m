function F = Fmat2(theta)
F=zeros(13, 13);


% Transition to PB 0  from ages 5-9
for i = 5:9
    % Transition to S
    F(1, i) = 0.5* theta(2) * theta(i) * theta(10); 
end
F(1,10)=F(1,9);

% Transition from S, F, NB to S, F, NB
F(1, 11) = 0.5* theta(3) * theta(11) * theta(14); 

F(1, 12) = 0.5* theta(4) * theta(12) * theta(14); 

F(1, 13) = 0.5* theta(4) * theta(13) * theta(14); 

return