% Fig. 3 Influence of heritability and climate on projected population dynamics of blackbrowed
% albatross. (A–D) Projected total population size from 2006 to 2100 for four phenotypes
% (activity, time on water, return date, wing length) under two climate scenarios: a moderately highemission
% pathway (SSP3-7.0) and a low-emission scenario consistent with the Paris Agreement, and
% two heritability values (h2 = 0.1, 0.9). Solid lines represent SSP3-7.0; dotted lines represent the
% Paris scenario. Colors denote heritability (blue = low; purple = high). Shaded areas indicate 90%
% confidence intervals incorporating demographic and climate uncertainty. Observed estimates from an
% integral Bayesian population model are shown in black (mean = solid; 90% CI = dotted). (E) Time
% of extinction and (F) probability of extinction for a 99% threshold. Boxes indicate the interquartile
% range, with medians as horizontal lines and whiskers spanning the 5th–95th percentile. Climate
% projections are from the Community Earth System Model.
clear; close all; clc;
addpath(genpath(pwd))

%% INITIATE #######################################
% ******************** PHENOTYPE **************************************
% 1: Time resting on the water
% 2: Number of landings / take-offs
% 3: return date
% 4: wing length
phenotypeNames = {
    'Activity', ...     % 1 Number of landings / take-offs
    'Time water', ...   % 2 Time resting on the water
    'Return date', ...  % 3
    'Wing length'       % 4
    };
% Phenotype Observed ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
load ('FOR.mat') % FORAGING: 1: year; 2: Number of landings / take-offs; 3. 'Time resting on the water'; 4: return date for all year
load wing_corrected.mat % wing length
FOR_mean = mean(FOR(:,2:end)); % Mean foraging phenotype
%%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
xp=6; % min (-xp) and max (xp) of phenotype and breeding value bins

% number of individuals to simulate
nind = 2390;
nsim=100;
% ******************** DIMENSIONS **************************************

%---------------------------------
% Three dimensions (m) of stages:
% 1) Age
% 2) Breeding value
% 3) Phenotype
m = 3;
%---------------------------------

%---------------------------------
% Set dimensions for stages
w = 13; % age (or stage)
% Set dimensions for phenotypes
g = 30; % # phenotype classes
% Set dimensions for breeding value
b = 30; % # breeding value classes
%***********************************************************************

% cliamte models information
caseNames = ["CESM2-LE", "RCP 4.5", "Paris 2", "Paris 1.5"];
timeCESM = 2006:2100;

%#####################################################
%% RUN The model forfuture Sea Surface Temperature (SST)############################
% Builds phenotype–environment–vital rate parameters (theta) for the chosen phenotype,  as a function of SST.
% Initializes a Gaussian distribution of phenotypes and breeding values with variance components set by heritability h2.
% Constructs sparse block matrices for survival/transition (U), reproduction (R), breeding-value inheritance (H), and phenotype assignment (M).
% Runs a burn-in (nit_0) to reach a stable joint distribution, rescales to nind, then runs the main projection (nit).
% Aggregates outputs: population size through time, distributions of breeding values and phenotypes, means/variances breeding values and phenotypes, adaptation rate, and mean vital rates weighted by phenotype distributions.

% % OUTputs for main_Pheno_ENV_ClimateChange_UNC.m ###########################################
%
% - Time and grid outputs
%
% nit (scalar): number of time steps in main projection.
% midpoint_e (1xg): phenotype bin midpoints.
% midpoint_a (1xb): breeding value bin midpoints.
% xp (scalar): range used to define midpoint.
%
% - Population and distribution outputs
%
% NN (w × b × g × nit): full population distribution through time, structured as
% age ×  breeding value bin × phenotype x time
% NN_tot (nit×1): total population size through time, obtained by integrating NN over structured dimensions (with binwidth scaling).
%

% ^^^^^^^^^^^^^^^^^^^Sea Surface Temperature ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
SST=[  -0.7563   -0.3128   -0.8093]; % 1986:2022



for caseID=[1 3]
    %% ******************** CLIMAT **************************************
    nit = length(timeCESM); %number of years
    switch caseID
        case 1 % CESM2-LE
            load('ClimateScenario_Case1.mat','ts_breedinga','ts_juvenilea','ts_wintera')
            % timeCESM = 1870:2100;
            nens = 40;
        case 2 % RCP 4.5
            load('ClimateScenario_Case2.mat','ts_breedinga','ts_juvenilea','ts_wintera')
            % timeCESM = 2006:2080;
            nens = 15;
        case 3 % Paris 2
            load('ClimateScenario_Case3.mat','ts_breedinga','ts_juvenilea','ts_wintera')
            % timeCESM = 2006:2100;
            nens = 11;
        case 4 % Paris 1.5
            load('ClimateScenario_Case4.mat','ts_breedinga','ts_juvenilea','ts_wintera')
            % timeCESM = 2006:2100;
            nens = 5;
        otherwise
            error('Invalid caseID. Please choose a value between 1 and 4.');
    end

% Compute the mean over ensemble members
mean_ts_juvenilea = mean(ts_juvenilea, 2);
mean_ts_wintera = mean(ts_wintera, 2);
mean_ts_breedinga = mean(ts_breedinga, 2);

    for PHENOTYPE=1:4
        for h2=[0.1 0.9]

            run('main_Pheno_ENV_ClimateChange_UNC.m')

            save(['ecoEvoResults_Cscenario_STO_', num2str(caseID),'_h2_',num2str(h2, '%.1f'), '_PHENOTYPE_', num2str(PHENOTYPE),'.mat'], ...
                'N_all','NN_tot_all', 'THETAtime_all');

        end
    end
end


%% ######## FIGURE ####################################
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%% Figure 3: Influence of heritability and climate on projected population dynamics of black-
%browed albatross.
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
phenotypeNames = {'Activity', 'Time water', 'Return date', 'Wing length'};
heritabilities = [0.1,0.9];
climateScenarios = ["CESM2-LE",  "Paris 2"];
years = 1986:2100;
timeCESM=2006:2100;
w=13; b=30; g=30;
nsim=150;
Nmedian=zeros(length(timeCESM),numel(phenotypeNames), numel(heritabilities),numel(climateScenarios));
Nlow=Nmedian; Nhigh=Nmedian;
N_tot_store_all = cell(numel(phenotypeNames), numel(heritabilities), numel(climateScenarios));
load('Nobs_FRA.mat')
t_obs = 1986:2022;
N0 = Ntot_obs(find(t_obs==2006),1);  % Initial population size in 2006
extProb = zeros(numel(phenotypeNames), numel(heritabilities),numel(climateScenarios));
extTime = NaN(nsim, numel(phenotypeNames), numel(heritabilities),numel(climateScenarios));
Nthreshold=(1-0.99)*N0;

for pIdx = 1:numel(phenotypeNames)
    for hIdx = 1:numel(heritabilities)
        for cIdx =1:2
            h2 = heritabilities(hIdx);
            PHENOTYPE = pIdx;
            if cIdx==1
                caseID = 1;
            elseif cIdx ==2
                caseID = 3;
            end
            filename=['ecoEvoResults_Cscenario_STO_', num2str(caseID),'_h2_',num2str(h2, '%.1f'), '_PHENOTYPE_', num2str(PHENOTYPE),'.mat'];
            %run main_Pheno_ENV_Cscenario_STO.m
            load(filename);
            [S,nit,nsim]=size(N_all);
            N_tot=zeros(nit,nsim);
            for s=1:nsim
                Ns     = reshape(N_all(:,:,s),[w,b,g,nit]); %pop strutured by stage * breeding values; phenotype, time
                Ns_tot = permute(sum(Ns*binwidth_a*binwidth_e,[1,2,3]),[4,1,2,3]);
                N_tot(:,s)=Ns_tot;
                belowThresh = find(Ns_tot < Nthreshold, 1, 'first');
                if ~isempty(belowThresh)
                    extTime(s,pIdx, hIdx, cIdx) = timeCESM(belowThresh);
                end
            end
            N_tot_store_all{pIdx, hIdx, cIdx} = N_tot;  % Store all simulations
            Nq=quantile(N_tot,[0.05 0.5 0.95],2);
            Nmedian(:,pIdx, hIdx,cIdx)=Nq(:,2);
            Nlow(:,pIdx, hIdx,cIdx)=Nq(:,1);
            Nhigh(:,pIdx, hIdx,cIdx)=Nq(:,3);
            extProb(pIdx, hIdx,cIdx) = sum(~isnan(extTime(:,pIdx, hIdx,cIdx))) / nsim;
        end
    end
end

%%
figure('Units','normalized','Position',[0.05 0.05 0.9 0.9]);
clim_colors = [0 0.4470 0.7410; 0.4940 0.1840 0.5560];  % blue & purple
panelLetters = {'A', 'B', 'C', 'D'};

for pIdx = 1:numel(phenotypeNames)
    subplot(3,2,pIdx); hold on;

    % Solid lines: CESM2 (SSP3-7.0)
    for hIdx = 1:2
        plot(timeCESM, Nmedian(:,pIdx, hIdx,1), 'LineWidth', 3, ...
            'Color', clim_colors(hIdx,:));
        fill([timeCESM, fliplr(timeCESM)], ...
            [Nlow(:,pIdx, hIdx,1); flipud(Nhigh(:,pIdx, hIdx,1))]', ...
            clim_colors(hIdx,:), 'FaceAlpha', 0.3, 'EdgeColor', 'none');
    end

    % Dashed lines: Paris Agreement scenario
    for hIdx = 1:2
        plot(timeCESM, Nmedian(:,pIdx, hIdx,2), ':','LineWidth', 3, ...
            'Color', clim_colors(hIdx,:));
        fill([timeCESM, fliplr(timeCESM)], ...
            [Nlow(:,pIdx, hIdx,2); flipud(Nhigh(:,pIdx, hIdx,2))]', ...
            clim_colors(hIdx,:), 'FaceAlpha', 0.1, 'EdgeColor', 'none');
    end

    % Observed data
    load Nobs_FRA.mat

    % Overlay observed population data
    t_obs = 1986:2022;
    if exist('Ntot_obs', 'var') && size(Ntot_obs,1) == length(t_obs)
        plot(t_obs, Ntot_obs(:,1), 'k', 'LineWidth', 2, 'DisplayName', 'Obs Mean');
        plot(t_obs, Ntot_obs(:,2), 'k:', 'LineWidth', 1);
        plot(t_obs, Ntot_obs(:,3), 'k:', 'LineWidth', 1);
    end


    % Panel A legend
    if pIdx == 1
        h1 = plot(nan, nan, '-', 'Color', clim_colors(1,:), 'LineWidth', 3);
        h2 = plot(nan, nan, '-', 'Color', clim_colors(2,:), 'LineWidth', 3);
        h3 = plot(nan, nan, ':', 'Color', clim_colors(1,:), 'LineWidth', 3);
        h4 = plot(nan, nan, ':', 'Color', clim_colors(2,:), 'LineWidth', 3);
        h5 = plot(nan, nan, 'k', 'LineWidth', 2);
        h6 = plot(nan, nan, 'k:', 'LineWidth', 1);

        legend([h1, h2, h3, h4, h5, h6], { ...
            'High emissions h^2=0.1', 'High emissions h^2=0.9', ...
            'Low emissions h^2=0.1', 'Low emissions h^2=0.9', ...
            'Obs mean', 'Obs 90% CI' ...
            }, 'Location', 'northeastoutside', 'FontSize', 24);
    end

    title(sprintf('%s. %s', panelLetters{pIdx}, phenotypeNames{pIdx}), 'FontSize', 24);
    ylabel('Number of individuals');
    xlabel('Year');
    set(gca, 'FontSize', 24); grid on;

end

boxColors = [
    1.0, 0.8, 0.0;      % High emissions h²=0.1
    0.85, 0.33, 0.10;   % High emissions h²=0.9
    0.0, 0.45, 0.74;    % Low emissions h²=0.1
    0.494, 0.184, 0.556 % Low emissions h²=0.9
    ];

climateScenarios = {'High emissions', 'Low emissions'};
nPhen = numel(phenotypeNames);
nH2 = numel(heritabilities);
nClim = numel(climateScenarios);

% === Subplot E: Extinction Year Boxplot ===
subplot(3,2,5); hold on;

% Initialize containers
phenLabels = [];
timeData = [];
colorGroup = [];

groupIdx = 1;
nSim = size(extTime, 1);

for c = 1:nClim
    for h = 1:nH2
        for p = 1:nPhen
            tmp = squeeze(extTime(:,p,h,c));
            tmp = tmp(~isnan(tmp));

            % Extend data
            timeData = [timeData; tmp];
            phenLabels = [phenLabels; repmat(p, length(tmp), 1)];
            colorGroup = [colorGroup; repmat((c-1)*nH2 + h, length(tmp), 1)];
        end
    end
end

% Convert phenotype index to categorical with trait labels
phenLabelsCat = categorical(phenLabels, 1:nPhen, phenotypeNames);

% Draw box chart with correct grouping
g = boxchart(phenLabelsCat, timeData, 'GroupByColor', colorGroup);

% Apply correct color to each group (4 groups: 2 climates × 2 h²)
for i = 1:numel(g)
    g(i).BoxFaceColor = boxColors(i,:);
end

% Format axes and labels
ylabel('Year of extinction (≥99% decline)', 'FontSize', 24);
set(gca, 'FontSize', 24);
title('E. Extinction Year by Trait and Scenario', 'FontSize', 24);
grid on;

% === Subplot F: Extinction Probability Bar Plot ===
subplot(3,2,6); hold on;

% Reshape extProb: [nPhen x (nClim * nH2)]
barData = reshape(extProb, [nPhen, nClim * nH2]);  % e.g., [4 x 4]

% Create grouped bar plot
bh = bar(barData, 'grouped');

% Assign consistent colors
for k = 1:numel(bh)
    bh(k).FaceColor = boxColors(k,:);
    bh(k).FaceAlpha = 0.7;  % optional transparency
end

% Axes and labels
set(gca, 'XTickLabel', phenotypeNames, 'FontSize', 24);
ylabel('Probability of extinction (≥99% decline)', 'FontSize', 24);
title('F. Extinction Probability by Trait and Scenario', 'FontSize', 24);
legend({'High emissions h²=0.1', 'High emissions h²=0.9', ...
    'Low emissions h²=0.1', 'Low emissions h²=0.9'}, ...
    'Location', 'northeastoutside', 'FontSize', 24);
grid on;

%exportgraphics(gcf,'fig2.pdf','ContentType','vector','BackgroundColor','none')
