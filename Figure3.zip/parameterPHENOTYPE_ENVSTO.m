function [theta] = parameterPHENOTYPE_ENVSTO(AILE, FOR, g, SST, selSj) 
% This function creates the demographic parameter matrix (theta) used to
% parameterize the eco-evolutionary matrix population model.
%
% Relative to the deterministic version (parameterPHENOTYPE_ENV), this
% function incorporates stochastic temporal variation in demographic rates.
% For each annual projection, random deviations are added to the linear
% predictors of the demographic models using normally distributed random
% effects whose standard deviations were estimated from long-term
% demographic analyses of Southern Fulmars (Jenouvrier et al. 2018).
%
% These stochastic deviations represent annual environmental variability
% affecting demographic rates while preserving the underlying mean
% relationships between climate, phenotype, and vital rates.
%
% An optional scenario (selSj = 1) allows the strength of selection on
% juvenile survival to increase with warmer sea-surface temperatures.
%
% Reference:
% Jenouvrier, S., Aubry, L.M., Barbraud, C., Weimerskirch, H., & Caswell, H.
% (2018). Interacting effects of unobserved heterogeneity and individual
% stochasticity in the life history of the Southern Fulmar.
% Journal of Animal Ecology, 87, 212–222.
% DESCRIPTION OF INPUTS
%
% AILE = Wing-length values for the phenotype classes.
%        AILE is a vector containing one wing-length value for each of the
%        g phenotype classes. Wing length is measured at fledging.
%
% FOR  = Foraging and phenological trait values for the phenotype classes.
%        FOR is a g-by-3 matrix, with one row for each phenotype class:
%           Column 1: FOR, foraging activity expressed as the number of
%                     transitions between activity and rest on the water
%           Column 2: ACT, proportion of time spent on the water
%           Column 3: Return date to the breeding colony
%
% g    = Number of phenotype classes and number of columns in theta.
%
% SST  = Sea-surface-temperature covariates for the current year.
%        SST contains the environmental variables used to calculate the
%        climate-dependent demographic parameters:
%           SST(1,1): SST covariate affecting first-year survival
%           SST(1,2): SST covariate affecting pre-breeder breeding success
%                     and adult breeding probabilities
%           SST(1,3): Additional SST covariate affecting pre-breeder
%                     breeding success and adult breeding probabilities
%
% DESCRIPTION OF OUTPUT
%
% theta = 14-by-g matrix of demographic parameters.
%         Each column corresponds to one phenotype class, and the rows
%         contain the following parameters:
%            Row 1:    First-year survival
%            Rows 2-4: Adult survival probabilities
%            Rows 5-9: Age-specific recruitment probabilities
%            Row 10:   Pre-breeder breeding success
%            Rows 11-13: Adult breeding probabilities conditional on
%                        previous breeding state
%            Row 14:   Adult breeding success

% selSj = Indicator defining the juvenile-survival selection scenario:
%            selSj = 0: baseline relationship among first-year survival,
%                        SST, and wing length, with stochastic variation
%            selSj = 1: scenario with increased selection on wing length
%                        under warmer sea surface temperatures



%% INITIALIZE theta matrix
theta = zeros(14, g); % There are 14 parameters. 
% Because environmental conditions change at each year, parameters in theta need to be re-estimated each year

% First year survival Function of SST and wing length

if selSj==0 %baseline
   theta(1, :) = invlogit(-0.23 - 0.24.*SST(1, 1) - 0.32.*SST(1, 1).^2 + 0.368056458*AILE'+randn(1,g)*0.389); % Effect of SST in juvenile sector + effect of wing length
elseif selSj==1 % Wing length is subject to increased selection under warmer sea surface temperatures 
    theta(1, :) =invlogit(-0.23 +0.1*(-0.24.*SST(1, 1) - 0.32.*SST(1, 1).^2) + 0.368056458*AILE'*SST(1, 1)+randn(1,g)*0.389); % Effect of SST in juvenile sector + effect of wing length
end

% adult survival 
theta(2, :) = invlogit( ones(1,g).*2.5+(randn(1,g)*0.1532)); % Survival Pre-breeders
theta(3, :) = invlogit( ones(1,g).*2.753910654+(randn(1,g)*0.125340816));% Survival Successful
theta(4, :) = invlogit( ones(1,g).*2.438845855+(randn(1,g)*0.105823902));% Survival Failed=Non-breeders
% recruitment probabilities: Function of age (different intercepts for each age) and wing length  
theta(5, :) = invlogit(-4.891594061+ randn(1,g)*0.399466259 +   (0.385926122+randn(1,g)*0.096180444).*AILE'); % age 4;  
theta(6, :) = invlogit(-3.556583792 + randn(1,g)*0.231925604 +(0.385926122+randn(1,g)*0.096180444).*AILE'); % age 5;  
theta(7, :) = invlogit(-2.247152916 +randn(1,g)*0.149324983+(0.385926122+randn(1,g)*0.096180444).*AILE'); % age 6;  
theta(8, :) = invlogit(-1.511223273 + randn(1,g)* 0.13625766 +(0.385926122+randn(1,g)*0.096180444).*AILE'); % age 7;  
theta(9, :) = invlogit(-0.8954 +(0.385926122+randn(1,g)*0.096180444).*AILE'); % age 8+;  
% breeding success PB Function of SST 
theta(10,:)=ones(1, g).*invlogit(-0.300619322 - 0.154409282.*SST(1, 2) - 0.049391794.*SST(1, 2).^2 + 0.135000818.*SST(:, 3) + 0.135000818.*SST(1, 3).^2+ randn(1,g).*-2.9598);

% Breeding probabilities of Adult
%Successful
theta(11,:) = exp(1.2843 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) ./ ...
               (1 + exp(1.2843 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) + ...
                    exp(0.6537 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2)) ...
             + exp(0.6537 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) ./ ...
               (1 + exp(0.6537 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) + ...
                    exp(1.2843 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2)) + randn(1,g).*0.0358;

%Failed
theta(12,:) = exp(0.8144 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) ./ ...
               (1 + exp(0.8144 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) + ...
                    exp(0.3905 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2)) ...
             + exp(0.3905 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) ./ ...
               (1 + exp(0.3905 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) + ...
                    exp(0.8144 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2)) + randn(1,g).*0.0407;

% Non-breeders
theta(13,:)=exp(0.0130 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) ./ ...
(1 + exp(0.0130 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2) + ...
     exp(-0.2112 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2)) ...
+ exp(-0.2112 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) ./ ...
(1 + exp(-0.2112 + 0.0301.*SST(1, 2) - 0.0573.*SST(1, 2).^2 + 0.2029.*SST(1, 3) + 0.0783.*SST(1, 3).^2) + ...
     exp(0.0130 - 0.1544.*SST(1, 2) - 0.0494.*SST(1, 2).^2 + 0.1350.*SST(1, 3) + 0.1241.*SST(1, 3).^2))+randn(1,g).*0.0715;

% breeding success adult (no differences among breeding stages): Function
% of forgaing behaviors
theta(14,:)=invlogit( ...
    (0.9785+randn(1,g)*0.2354 )+ ...
    (0.4366+randn(1,g)*0.1995).*FOR(:, 3)'+ ...
    (1.3643+randn(1,g)*0.5104).*FOR(:, 1)' - ...
    (0.4593+randn(1,g)*0.2476).*FOR(:, 2)');

return
