function U = Umat2(theta)
U=zeros(13, 13);

U(2,1)=theta(1);
% Populate the matrix based on the table
% Age transitions
for i = 2:4
        U(i+1, i) = theta(2); 
end

% Age transitions with (1 - theta)
for i = 5:9
    U(i+1, i) = theta(2) * (1 - theta(i)); 
end
U(10,10)=theta(2) * (1 - theta(9));

% Transition to S, F, NB from ages 5-9
for i = 5:9
    % Transition to S
    U(11, i) = theta(2) * theta(i) * theta(10); 
    % Transition to F
    U(12, i) = theta(2) * theta(i) * (1 - theta(10)); 
end
U(11:12,10)=U(11:12,9);

% Transition from S, F, NB to S, F, NB
U(11, 11) = theta(3) * theta(11) * theta(14); 
U(12, 11) = theta(3) * theta(11) * (1 - theta(14)); 
U(13, 11) = theta(3) * (1 - theta(11)); 

U(11, 12) = theta(4) * theta(12) * theta(14); 
U(12, 12) = theta(4) * theta(12) * (1 - theta(14)); 
U(13, 12) = theta(4) * (1 - theta(12)); 

U(11, 13) = theta(4) * theta(13) * theta(14); 
U(12, 13) = theta(4) * theta(13) * (1 - theta(14));
U(13, 13) = theta(4) * (1 - theta(13)); 

return