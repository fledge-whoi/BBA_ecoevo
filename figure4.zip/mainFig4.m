% Fig. 4 Eco-evolutionary dynamics of black-browed albatross traits under low-emissions
% climate projections, comparing alternative selective pressures. Two heritability values (h2 =
% 0.1 and 0.9) are shown; solid lines represent h2 = 0.1 and dotted lines represent h2 = 0.9. Wing length
% is either subject to increased selection under warmer sea surface temperatures (green) or assumed
% to be unaffected by climate change (baseline; purple). (A,B) Demographic outcomes from 2006 to
% 2100. (C,D) Final (2100) and initial (2006) distributions of breeding values and phenotypes. Initial
% trait distributions are shown only for the baseline scenario with h2 = 0.1 (grey bars).

%This MATLAB workflow runs an eco-evolutionary, stage-structured projection for one focal phenotype (chosen by PHENOTYPE) over nit annual time steps.
% Individuals are structured by:
%age/stage (w age classes within each breeding state),
% breeding state (b states),
%breeding value category (g bins),
% phenotype category (g bins).

%% INITIATE #################################################
clear; close all; clc;
% Specify phenotype  
% 4: wing length
PHENOTYPE = 4;
% and Specify  climate scenario 
%caseID = 1; % high emission
caseID = 3; % low emission Paris 2

% ******************** PHENOTYPE **************************************
% 1: Time resting on the water
% 2: Number of landings / take-offs
% 3: return date
% 4: wing length
phenotypeNames = {
    'Activity', ...     % 1 Number of landings / take-offs
    'Time water', ...   % 2 Time resting on the water
    'Return date', ...  % 3
    'Wing length'       % 4
    };
% Phenotype Observed ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
load ('FOR.mat') % FORAGING: 1: year; 2: Number of landings / take-offs; 3. 'Time resting on the water'; 4: return date for all year
load wing_corrected.mat % wing length
FOR_mean = mean(FOR(:,2:end)); % Mean foraging phenotype

% ******************** DIMENSIONS **************************************
%---------------------------------
% Three dimensions (m) of stages:
% 1) Age
% 2) Breeding value
% 3) Phenotype
m = 3;
%---------------------------------

%---------------------------------
% Set dimensions for stages
w = 13; % age (or stage)
% Set dimensions for phenotypes
g = 100; % # phenotype classes
% Set dimensions for breeding value
b = 100; % # breeding value classes
%***********************************************************************
% number of individuals to simulate
nind = 2390;
%nind=2815;

%% ******************** CLIMAT **************************************
caseNames = ["CESM2-LE", "RCP 4.5", "Paris 2", "Paris 1.5"];
timeCESM = 2006:2100;
nit = length(timeCESM); %number of years
switch caseID
    case 1 % CESM2-LE
        load('ClimateScenario_Case1.mat','ts_breedinga','ts_juvenilea','ts_wintera')
        % timeCESM = 1870:2100;
        nens = 40;
    case 2 % RCP 4.5
        load('ClimateScenario_Case2.mat','ts_breedinga','ts_juvenilea','ts_wintera')
        % timeCESM = 2006:2080;
        nens = 15;
    case 3 % Paris 2
        load('ClimateScenario_Case3.mat','ts_breedinga','ts_juvenilea','ts_wintera')
        % timeCESM = 2006:2100;
        nens = 11;
    case 4 % Paris 1.5
        load('ClimateScenario_Case4.mat','ts_breedinga','ts_juvenilea','ts_wintera')
        % timeCESM = 2006:2100;
        nens = 5;
    otherwise
        error('Invalid caseID. Please choose a value between 1 and 4.');
end

% Compute the mean over ensemble members
mean_ts_juvenilea = mean(ts_juvenilea, 2);
mean_ts_wintera = mean(ts_wintera, 2);
mean_ts_breedinga = mean(ts_breedinga, 2);


%% RUN The model for Future Sea Surface Temperature (SST) enssemble mean:
% Builds phenotype–environment–vital rate parameters (theta) for the chosen phenotype,  as a function of SST.
% Initializes a Gaussian distribution of phenotypes and breeding values with variance components set by heritability h2.
% Constructs sparse block matrices for survival/transition (U), reproduction (R), breeding-value inheritance (H), and phenotype assignment (M).
% Runs a burn-in (nit_0) to reach a stable joint distribution, rescales to nind, then runs the main projection (nit).
% Aggregates outputs: population size through time, distributions of breeding values and phenotypes, means/variances breeding values and phenotypes, adaptation rate, and mean vital rates weighted by phenotype distributions.

% %Required inputs ###########################################
%      - PHENOTYPE (integer): selects which trait is modeled.
% 1 = number of landings / take-offs
% 2 = time resting on the water
% 3 = return date
% 4 = wing length
% 
%     - h2 (scalar in [0,1]): narrow-sense heritability used to partition phenotypic variance into additive genetic and environmental components (Va = Vp*h2, Ve = Vp - Va).
%     - nit (integer): number of time steps for the main projection (here 115, corresponding to 1986–2100 ).
%     - nind (integer): initial total population size used to scale the post burn-in distribution (here 2815).
% 
%     - Dimensions
% w (integer): number of age classes within each breeding state  
% g (integer): number of bins for phenotype value categories  
% b (integer): number of bins for breeding values.
% 
%     - Trait and covariate data (empirical inputs)
% Wing (vector): wing length data (used when PHENOTYPE = 4).
% FOR (matrix): foraging data where columns are used as:
%                        FOR(:,2) = landings / take-offs (PHENOTYPE 1)
%                        FOR(:,3) = time on water / resting (PHENOTYPE 2)
%                         FOR(:,4) = return date (PHENOTYPE 3)
% FOR_mean (vector or scalar): mean foraging covariates 
% SST (vector time series or scalar): sea surface temperature covariate 

% % OUTputs ###########################################
% 
% - Time and grid outputs
% 
% nit (scalar): number of time steps in main projection.
% midpoint_e (1xg): phenotype bin midpoints.
% midpoint_a (1xb): breeding value bin midpoints.
% xp (scalar): range used to define midpoint.
% 
% - Population and distribution outputs
% 
% NN (w × b × g × nit): full population distribution through time, structured as
% age ×  breeding value bin × phenotype x time
% NN_tot (nit×1): total population size through time, obtained by integrating NN over structured dimensions (with binwidth scaling).
% 
% - Breeding value outputs
% 
% m_ebvs (1×nit): mean breeding value through time (population-weighted average of midpoint_a).
% m_ebvs2 (b×nit): normalized breeding value distribution through time (each time step sums to 1 after binwidth scaling).
% Va_hat (1×nit): estimated additive genetic variance of breeding values through time, computed from ebvs and m_ebvs.
% 
% - Phenotype outputs
% 
% Pheno (g×nit): phenotype distribution of the total population through time (integrated over age and breeding values).
% mz (1×nit): mean phenotype of the total population through time.
% Mz (wxnit)
% Vp_hat (1×nit): estimated phenotypic variance through time
% 
% Vital-rate summaries (phenotype-weighted means)
% These are phenotype-weighted mean rates through time, computed from Thetatime and Pheno:
% 
% - S1z (1×nit): mean of juvenile survival through time.
% - R4z, R5z, R6z, R7z, R8z, R9z (1×nit): mean recruitment probabilities  (parameters 5–9 as indexed for age) through time.
% - BSz (1×nit): mean breeding success through time.

for h2=[0.1 0.9]
    for CaseSP=[0 1]; % baseline 0; selective pressure dependent of SST 1

        run('main_Pheno_ENV_ClimateChange_meanEns.m')

        if CaseSP==0
            fname = sprintf('ecoEvoResults_Cscenario_%d_h2_%.1f_PHENOTYPE_%d.mat', caseID, h2, PHENOTYPE);
        elseif CaseSP==1
            fname = sprintf('ecoEvoResults_Cscenario_PressureSST%d_h2_%.1f_PHENOTYPE_%d.mat', caseID, h2, PHENOTYPE);
        end
        save(fname, ...
            'nit', 'm_ebvs', 'Va_hat', 'm_ebvs2', ...
            'mz','Mz', 'Vp_hat', 'pheno', 'midpoint_e', ...
            'S1z', 'R4z', 'R5z', 'R6z', 'R7z', 'R8z', 'R9z','BSz', ...
            'NN', 'NN_tot','midpoint_a', 'xp');

    end
end
%% ############################################
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%% Figure 4: Eco-evolutionary dynamics of black-browed albatross traits under low-emissions
%climate projections, comparing alternative selective pressures. 
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
LW=3; % linewidth for plots
%% --- Settings ---
PHENOTYPE = 4;
caseID    = 3;                 % your choice (e.g., low-emission)
h2_vals   = [0.1 0.9];
timeCESM  = 2006:2100;

% Grid setup (must match how results were generated)
[w,b,g,nit]=size(NN);

% Bin definitions (must match results)
min_pheno = -6; max_pheno = 6;
edges_e = linspace(min_pheno, max_pheno, g+1);
midpoint_e = (edges_e(1:end-1)+edges_e(2:end))/2;
binwidth_e = edges_e(2) - edges_e(1);

min_breeding = -6; max_breeding = 6;
edges_a = linspace(min_breeding, max_breeding, g+1);
midpoint_a = (edges_a(1:end-1)+edges_a(2:end))/2;
binwidth_a = edges_a(2) - edges_a(1);

% Scenarios to compare
scenarioNames = {'Baseline', 'SST selective pressure'};
scenarioKeys  = {'baseline', 'sstpress'};   % internal tags

% Colors: lighter for h2=0.1, darker for h2=0.9
baseLight = [0.65 0.45 0.75];   % light purple
baseDark  = [0.35 0.20 0.50];   % dark purple
sstLight  = [0.40 0.70 0.45];   % light green
sstDark   = [0.00 0.45 0.20];   % dark green

% Line styles: solid for h2=0.1, dotted for h2=0.9
lineStyles = {'-', ':'};

%% --- Figure layout ---
fi = 18;
figure('Position', [100 100 1200 650]);

panelTitles = { ...
    'Total population size', ...
    'Mean juvenile survival', ...
    'Breeding value distribution (2100)', ...
    'Phenotype distribution (2100)'};

subplot_labels = {'A','B','C','D'};

for i = 1:4
    subplot(2,2,i);
    title(['\bf' subplot_labels{i} '. ' panelTitles{i}], 'FontSize', fi);
    hold on; box on; grid on;
    set(gca,'FontSize',fi);
end

%% --- Helper to choose color by scenario + h2 ---
getColor = @(scKey, hi) ...
    (strcmp(scKey,'baseline') * (hi==1)*baseLight + strcmp(scKey,'baseline')*(hi==2)*baseDark + ...
     strcmp(scKey,'sstpress') * (hi==1)*sstLight + strcmp(scKey,'sstpress')*(hi==2)*sstDark);

%% --- Loop over scenario and heritability ---
legendHandles = gobjects(4,1);
legendText = cell(4,1);
legIdx = 0;

for sc = 1:2
    scKey = scenarioKeys{sc};

    for hi = 1:2
        h2 = h2_vals(hi);
        ls = lineStyles{hi};

        % File naming
        switch scKey
            case 'baseline'
                fname = sprintf('ecoEvoResults_Cscenario_%d_h2_%.1f_PHENOTYPE_%d.mat', caseID, h2, PHENOTYPE);
            case 'sstpress'
                fname = sprintf('ecoEvoResults_Cscenario_PressureSST%d_h2_%.1f_PHENOTYPE_%d.mat', caseID, h2, PHENOTYPE);
        end

        if ~isfile(fname)
            warning('Missing file: %s', fname);
            continue;
        end

        % Load what we need
        load(fname, 'NN', 'S1z', 'm_ebvs2', 'pheno');

        % Total N(t)
        Ns     = reshape(NN,[w,b,g,nit]);
        NN_tot = permute(sum(Ns*binwidth_a*binwidth_e,[1,2,3]),[4,1,2,3]);

        col = getColor(scKey, hi);

        % Panel A: Total population size
        subplot(2,2,1);
        hLine = plot(timeCESM, NN_tot, ls, 'Color', col, 'LineWidth', LW);

        % store legend entries once (4 entries total)
        legIdx = legIdx + 1;
        legendHandles(legIdx) = hLine;
        legendText{legIdx} = sprintf('%s, $h^2=%.1f$', scenarioNames{sc}, h2);

        % Panel B: Juvenile survival
        subplot(2,2,2);
        plot(timeCESM, S1z, ls, 'Color', col, 'LineWidth', LW);

        % Panel C: Breeding values distribution
        subplot(2,2,3);

        dist_init_bv = m_ebvs2(:,1)   / max(m_ebvs2(:,1));
        dist_end_bv  = m_ebvs2(:,end) / max(m_ebvs2(:,end));

        % Baseline initial distribution only once (h2=0.1)
        if strcmp(scKey,'baseline') && hi==1
            bar(midpoint_a, dist_init_bv, 'FaceColor', [0 0 0], ...
                'FaceAlpha', 0.25, 'EdgeColor', 'none');
        end
        plot(midpoint_a, dist_end_bv, ls, 'Color', col, 'LineWidth', LW);

        % Panel D: Phenotype distribution
        subplot(2,2,4);

        dist_init_ph = pheno(:,1)   / max(pheno(:,1));
        dist_end_ph  = pheno(:,end) / max(pheno(:,end));

        if strcmp(scKey,'baseline') && hi==1
            bar(midpoint_e, dist_init_ph, 'FaceColor', [0 0 0], ...
                'FaceAlpha', 0.25, 'EdgeColor', 'none');
        end
        plot(midpoint_e, dist_end_ph, ls, 'Color', col, 'LineWidth', LW);

    end
end

%% --- Axes labels / limits ---
subplot(2,2,1);
xlabel('Year'); ylabel('Total population size');
legend(legendHandles, legendText, ...
    'Interpreter','latex', 'Location','northeastoutside', 'FontSize', 14);

subplot(2,2,2);
xlabel('Year'); ylabel('Juvenile survival');

subplot(2,2,3);
xlabel('Breeding value'); ylabel('Normalized density');
xlim([-3 4]);

subplot(2,2,4);
xlabel('Phenotype'); ylabel('Normalized density');
xlim([-3 4]);
legend({ ...
    '2006 Baseline, $h^2=0.1$', ...
    '2100 Baseline, $h^2=0.1$', ...
    '2100 Baseline, $h^2=0.9$', ...
    '2100 SST selection, $h^2=0.1$', ...
    '2100 SST selection, $h^2=0.9$'}, ...
     'Interpreter','latex', 'Location','northeastoutside', 'FontSize', 14);

set(gcf,'Renderer','painters')   % ensure vector rendering
exportgraphics(gcf,'figure4.pdf','ContentType','vector');
